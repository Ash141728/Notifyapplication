package com.jsp.Notification.Service;

import com.jsp.Notification.Model.Student;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {

    public String sendNotification(Student student)




















    {
        return "done";
    }
}
