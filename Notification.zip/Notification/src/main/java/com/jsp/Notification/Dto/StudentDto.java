package com.jsp.Notification.Dto;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "ashish")
@Data
@Builder
public class StudentDto {

    @Id
    private int id;
    private String studentName;
    private String studentLoc;

    private String studentEmail;

}
